package org.aiwolf.Kog;

/**
 * Created by ry0u on 15/08/06.
 */

import org.aiwolf.client.base.player.AbstractRole;
import org.aiwolf.client.lib.TemplateTalkFactory;
import org.aiwolf.common.data.*;
import org.aiwolf.common.data.Agent;
import org.aiwolf.common.net.GameInfo;
import org.aiwolf.common.net.GameSetting;

public class AbstractKogBasePlayer extends AbstractRole implements Player {

    protected int readTalkNumber = 0;
    protected Agent voteTarget = null;
    protected Agent toldVoteTarget = null;

    @Override
    public void initialize(GameInfo gameInfo, GameSetting gameSetting) {
        super.initialize(gameInfo, gameSetting);

        readTalkNumber = 0;
        voteTarget = null;
    }

    @Override
    public void dayStart() {
        readTalkNumber = 0;

        Agent attackedAgent = getLatestDayGameInfo().getAttackedAgent();

        toldVoteTarget = null;
        voteTarget = null;
    }

    @Override
    public String talk() {
        if(toldVoteTarget != null) {
            return TemplateTalkFactory.vote(toldVoteTarget);
        }

        return Talk.OVER;
    }

    @Override
    public String whisper() {
        return null;
    }

    @Override
    public Agent attack() {
        return null;
    }

    @Override
    public Agent divine() {
        return null;
    }

    @Override
    public Agent guard() {
        return null;
    }

    @Override
    public Agent vote() {
        return voteTarget;
    }


    @Override
    public void finish() {
        return;
    }
}
