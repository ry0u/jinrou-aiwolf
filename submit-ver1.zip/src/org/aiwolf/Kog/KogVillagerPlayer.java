package org.aiwolf.Kog;

import org.aiwolf.client.base.player.AbstractVillager;
import org.aiwolf.client.lib.TemplateTalkFactory;
import org.aiwolf.client.lib.Topic;
import org.aiwolf.client.lib.Utterance;
import org.aiwolf.common.data.*;
import org.aiwolf.common.net.GameInfo;

import java.util.*;

/**
 * Created by ry0u on 15/08/10.
 */
public class KogVillagerPlayer extends AbstractVillager {
    AdvanceGameInfo agi = new AdvanceGameInfo();
    Agent planningVoteAgent;
    Agent declaredPlanningVoteAgent;
    int readTalkListNum;
    Map<Agent, Role> comingoutRole = new HashMap<>();
    boolean overSeer = false;
    boolean overMedium = false;

    public KogVillagerPlayer() {
    }

    @Override
    public void dayStart() {
        this.declaredPlanningVoteAgent = null;
        this.planningVoteAgent = null;
        this.setPlanningVoteAgent();
        this.readTalkListNum = 0;
    }

    @Override
    public String talk() {
        if(this.declaredPlanningVoteAgent != this.planningVoteAgent) {
            String ret = TemplateTalkFactory.vote(this.planningVoteAgent);
            this.declaredPlanningVoteAgent = this.planningVoteAgent;
            return ret;
        } else {
            return TemplateTalkFactory.over();
        }
    }

    @Override
    public Agent vote() {
        return this.planningVoteAgent;
    }

    @Override
    public void finish() {

    }

    @Override
    public void update(GameInfo gameInfo) {
        super.update(gameInfo);

        List talkList = gameInfo.getTalkList();
        boolean existInspectResult = false;

        for(int i= this.readTalkListNum;i < talkList.size();i++) {
            Talk talk = (Talk)talkList.get(i);
            Utterance utterance = new Utterance(talk.getContent());

            if(utterance.getTopic().equals(Topic.COMINGOUT)) {
                comingoutRole.put(utterance.getTarget(),utterance.getRole());
            }

            switch(utterance.getTopic().ordinal()) {
                case 2:
                    break;
                case 3:
                    Agent seerAgent = talk.getAgent();
                    Agent inspectedAgent = utterance.getTarget();
                    Species inspectRusult = utterance.getResult();
                    Judge judge = new Judge(this.getDay(), seerAgent, inspectedAgent, inspectRusult);
                    this.agi.addInspectJudgeList(judge);
                    existInspectResult = true;
            }
        }

        this.readTalkListNum = talkList.size();
        if(existInspectResult) {
            this.setPlanningVoteAgent();
        }
    }

    public void setPlanningVoteAgent() {
        if(this.planningVoteAgent != null) {
            Iterator aliveAgentList = this.agi.getInspectJudgeList().iterator();

            while(aliveAgentList.hasNext()) {
                Judge voteAgentCandidate = (Judge)aliveAgentList.next();
                if(voteAgentCandidate.getTarget().equals(this.planningVoteAgent)) {
                    return;
                }
            }
        }

        ArrayList voteAgentCandidate1 = new ArrayList();
        List aliveAgentList1 = this.getLatestDayGameInfo().getAliveAgentList();
        aliveAgentList1.remove(this.getMe());
        Iterator var4 = this.agi.getInspectJudgeList().iterator();

        if(this.agi.getInspectJudgeList().size() > 0) {
            while (var4.hasNext()) {
                Judge rand = (Judge) var4.next();
                if (aliveAgentList1.contains(rand.getTarget()) && rand.getResult() == Species.WEREWOLF) {
                    voteAgentCandidate1.add(rand.getTarget());
                }
            }

            Random random = new Random();
            if (voteAgentCandidate1.size() > 0) {
                int id = random.nextInt(voteAgentCandidate1.size());
                this.planningVoteAgent = (Agent) voteAgentCandidate1.get(id);
            } else {
                int id = random.nextInt(aliveAgentList1.size());
                this.planningVoteAgent = (Agent) aliveAgentList1.get(id);
            }
        } else {
            ArrayList voteSeer = new ArrayList();
            ArrayList voteMeium = new ArrayList();

            Iterator ite = aliveAgentList1.iterator();
            while(ite.hasNext()) {
                Agent agent = (Agent)ite.next();
                if(this.comingoutRole.containsKey(agent)) {
                    if(this.comingoutRole.get(agent).equals(Role.SEER)) {
                        voteSeer.add(agent);
                    }
                    if(this.comingoutRole.get(agent).equals(Role.MEDIUM)) {
                        voteMeium.add(agent);
                    }
                }
            }

            Random rand = new Random();
            if(voteSeer.size() >= 3) {
                this.overSeer = true;
            }

            if(overSeer) {
                int id = rand.nextInt(voteSeer.size());
                this.planningVoteAgent = (Agent)voteSeer.get(id);
            }

            if(voteSeer.size() == 1) {
                this.overSeer = false;
            }

            if(voteMeium.size() >= 3) {
                this.overMedium = true;
            }

            if(overMedium) {
                int id = rand.nextInt(voteMeium.size());
                this.planningVoteAgent = (Agent)voteMeium.get(id);
            }

            if(voteMeium.size() == 1) {
                this.overMedium = false;
            }
        }
    }
}
