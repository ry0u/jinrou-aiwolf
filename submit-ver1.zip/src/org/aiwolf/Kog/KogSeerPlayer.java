package org.aiwolf.Kog;

import org.aiwolf.client.lib.TemplateTalkFactory;
import org.aiwolf.common.data.*;
import org.aiwolf.common.net.GameInfo;
import org.aiwolf.common.net.GameSetting;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by ry0u on 15/08/07.
 */
public class KogSeerPlayer extends AbstractKogBasePlayer {

    private Judge judge = null;
    private List<Judge> myJudgeList = new ArrayList<Judge>();
    private boolean isCo = false;
    private boolean isAgainstSeer = false;

    public KogSeerPlayer() {

    }

    @Override
    public void initialize(GameInfo gameInfo, GameSetting gameSetting) {
        super.initialize(gameInfo, gameSetting);
        this.isCo = false;
        this.isAgainstSeer = false;
    }

    @Override
    public void dayStart() {
        super.dayStart();

        if(getLatestDayGameInfo().getDivineResult() != null) {
            judge = getLatestDayGameInfo().getDivineResult();
            myJudgeList.add(judge);
        }
    }

    @Override
    public String talk() {
        if(!isCo) {
            for (Judge judge : getMyJudgeList()) {
                if (judge.getResult() == Species.WEREWOLF) {
                    String comingoutTalk = TemplateTalkFactory.comingout(getMe(), getMyRole());
                    isCo = true;
                    return comingoutTalk;
                }
            }

        }else {
            for(Judge judge: getMyJudgeList()) {
            }
        }

        return Talk.OVER;
    }

    @Override
    public Agent vote() {

        List<Agent> whiteAgent = new ArrayList<Agent>();
        List<Agent> blackAgent = new ArrayList<Agent>();

        for(Judge j : getMyJudgeList()) {
            if(getLatestDayGameInfo().getAliveAgentList().contains(judge.getTarget())) {
                switch (j.getResult()) {
                    case HUMAN:
                        whiteAgent.add(judge.getTarget());
                        break;
                    case WEREWOLF:
                        blackAgent.add(judge.getTarget());
                }
            }
        }

        if(blackAgent.size() > 0) {
            return randomSelect(blackAgent);
        } else {
            List<Agent> voteCandidates = new ArrayList<Agent>();
            voteCandidates.addAll(getLatestDayGameInfo().getAliveAgentList());
            voteCandidates.remove(getMe());
            voteCandidates.removeAll(whiteAgent);

            return randomSelect(voteCandidates);
        }
    }

    @Override
    public Agent divine() {
        GameInfo info = getLatestDayGameInfo();
        List<Agent> list = info.getAliveAgentList();
        Random rand = new Random();

        int select = rand.nextInt(list.size());
        return list.get(select);
    }

    public List<Judge> getMyJudgeList() {
        return this.myJudgeList;
    }

    public void setMyJudgeList(List<Judge> set) {
        this.myJudgeList.clear();

        for(int i=0;i<set.size();i++) {
            myJudgeList.add(set.get(i));
        }
    }

    public Agent randomSelect(List<Agent> list)  {
        Random rand = new Random();
        int d = rand.nextInt(list.size());

        List<Agent> ret = getLatestDayGameInfo().getAliveAgentList();
        return ret.get(d);
    }
}
