package org.aiwolf.Kog;

/**
 * Created by ry0u on 15/08/15.
 */
import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.List;
        import java.util.Map;
        import org.aiwolf.common.data.Agent;
        import org.aiwolf.common.data.Judge;
        import org.aiwolf.common.data.Role;

public class AdvanceGameInfo {
    private List<Judge> inspectJudgeList = new ArrayList();
    private List<Judge> mediumJudgeList = new ArrayList();
    private Map<Agent, Role> comingoutMap = new HashMap();

    public AdvanceGameInfo() {
    }

    public Map<Agent, Role> getComingoutMap() {
        return this.comingoutMap;
    }

    public void putComingoutMap(Agent agent, Role role) {
        this.comingoutMap.put(agent, role);
    }

    public void setComingoutMap(Map<Agent, Role> comingoutMap) {
        this.comingoutMap = comingoutMap;
    }

    public List<Judge> getInspectJudgeList() {
        return this.inspectJudgeList;
    }

    public void setInspectJudgeList(List<Judge> inspectJudgeList) {
        this.inspectJudgeList = inspectJudgeList;
    }

    public void addInspectJudgeList(Judge judge) {
        this.inspectJudgeList.add(judge);
    }

    public List<Judge> getMediumJudgeList() {
        return this.mediumJudgeList;
    }

    public void setMediumJudgeList(List<Judge> mediumJudgeList) {
        this.mediumJudgeList = mediumJudgeList;
    }

    public void addMediumJudgeList(Judge judge) {
        this.mediumJudgeList.add(judge);
    }
}
